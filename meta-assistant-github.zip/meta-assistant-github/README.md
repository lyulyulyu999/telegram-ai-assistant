# Meta Assistant 🍵

**个人知识管理 + AI 助理系统** - 基于 Telegram 双 Bot 架构

一个帮助你收集、整理、检索个人知识的智能助理系统。通过两个 Telegram Bot 协作：一个静默收集信息，一个提供 AI 交互和配置管理。

## ✨ 功能特点

- **📥 Bot 1 (收集)**: 静默保存笔记、想法、链接，AI 自动反馈
- **🎛 Bot 2 (控制)**: 配置中心 + AI 对话 + 搜索 + 草稿生成
- **🌐 Web 管理后台**: 可视化配置提示词、模型、功能开关
- **🔍 语义搜索**: 基于 ChromaDB 的向量检索
- **🤖 多模型支持**: Claude / GPT / Gemini / Llama 自由切换
- **📄 RAG 草稿**: 基于笔记库自动生成内容

## 🏗 系统架构

```
┌─────────────────┐     ┌─────────────────┐
│   Bot 1 (收集)   │     │   Bot 2 (控制)   │
│   静默保存笔记   │     │   AI对话/配置    │
└────────┬────────┘     └────────┬────────┘
         │                       │
         └───────────┬───────────┘
                     │
              ┌──────▼──────┐
              │  Node.js    │
              │  后端服务    │
              └──────┬──────┘
                     │
         ┌───────────┼───────────┐
         │           │           │
    ┌────▼────┐ ┌────▼────┐ ┌────▼────┐
    │ChromaDB │ │OpenRouter│ │Web Admin│
    │向量数据库│ │  AI API  │ │管理后台 │
    └─────────┘ └─────────┘ └─────────┘
```

## 🚀 快速开始

### 前置要求

- Node.js 18+
- Docker (用于 ChromaDB)
- 两个 Telegram Bot Token
- OpenRouter API Key

### 一、获取必要的 Token 和 Key

#### 1. 创建 Telegram Bot (需要两个)

1. 在 Telegram 搜索 [@BotFather](https://t.me/BotFather)
2. 发送 `/newbot`，按提示创建 Bot
3. 保存 Bot Token（格式：`123456789:ABCdefGHI...`）
4. **重复上述步骤创建第二个 Bot**

> 💡 建议命名：
> - Bot 1: `XXX_Input_Bot` (收集信息)
> - Bot 2: `XXX_Assistant_Bot` (AI 助理)

#### 2. 获取 OpenRouter API Key

1. 访问 [OpenRouter](https://openrouter.ai/)
2. 注册/登录账号
3. 在 [Keys 页面](https://openrouter.ai/keys) 创建 API Key
4. 保存 API Key

### 二、安装部署

```bash
# 1. 克隆项目
git clone https://github.com/你的用户名/meta-assistant.git
cd meta-assistant

# 2. 一键配置（填写所有 Token 和 Key）
./scripts/setup.sh

# 3. 启动所有服务
./scripts/start.sh
```

### 三、配置说明

运行 `setup.sh` 时会提示输入：

| 配置项 | 说明 | 示例 |
|--------|------|------|
| INPUT_BOT_TOKEN | Bot 1 的 Token | `123456:ABC...` |
| OUTPUT_BOT_TOKEN | Bot 2 的 Token | `789012:DEF...` |
| OPENROUTER_API_KEY | OpenRouter API Key | `sk-or-v1-...` |

## 📖 使用指南

### Bot 1 (收集 Bot)

直接发送任何内容即可保存：
- 文字笔记
- 链接
- 想法灵感

**命令：**
- `/start` - 查看帮助
- `/stats` - 查看统计

### Bot 2 (控制 Bot)

**命令：**
- `/start` 或 `/menu` - 打开控制台
- `/prompt` - 提示词管理

**控制台功能：**
- 📝 提示词管理 - 创建/编辑/切换 AI 人格
- 🤖 切换模型 - 选择不同的 AI 模型
- 💬 AI 对话 - 开启/关闭对话模式
- 🔍 搜索 - 语义搜索笔记
- 📄 草稿 - 基于笔记生成内容
- 📊 统计 - 查看笔记数量

### Web 管理后台

访问 `http://你的服务器IP:3001`

功能：
- 📊 仪表盘 - 统计概览
- 📝 提示词管理 - 可视化编辑
- 🤖 模型设置 - 为不同功能配置模型
- ⚙️ Bot 设置 - 功能开关
- 🔄 版本管理 - 配置快照

## 🔧 高级配置

### 端口说明

| 服务 | 默认端口 | 说明 |
|------|----------|------|
| Bot 服务 | 3000 | Telegram Webhook 接收 |
| 管理后台 | 3001 | Web 管理界面 |
| ChromaDB | 8000 | 向量数据库 |

### 使用 HTTPS (Webhook 必需)

Telegram Webhook 要求 HTTPS。开发环境推荐使用 **localtunnel**（无需注册）：

```bash
# 安装
npm install -g localtunnel

# 启动（在新终端）
lt --port 3000
```

或使用 **ngrok**：

```bash
# 安装后启动
ngrok http 3000
```

获取 HTTPS URL 后，更新 `.env` 中的 `WEBHOOK_URL`。

### 生产环境部署

推荐使用 PM2 管理进程：

```bash
# 安装 PM2
npm install -g pm2

# 启动所有服务
pm2 start scripts/ecosystem.config.js

# 设置开机自启
pm2 startup
pm2 save
```

## ❗ 常见问题

### Q: 按钮点击没有反应

**原因**: Webhook 没有包含 `callback_query` 类型

**解决**:
```bash
source .env
curl "https://api.telegram.org/bot$OUTPUT_BOT_TOKEN/setWebhook" \
  -d "url=$WEBHOOK_URL/webhook/output" \
  -d 'allowed_updates=["message","callback_query"]'
```

### Q: Webhook 返回 404

**原因**: Bot 服务没有运行，或 ngrok/localtunnel 已断开

**解决**:
1. 确认 Bot 服务正在运行：`ps aux | grep node`
2. 确认隧道服务正在运行
3. 检查 Webhook URL 是否正确

### Q: 收集消息后 Bot 2 没有反馈

**检查步骤**:
```bash
# 1. 检查 Webhook 状态
source .env
curl "https://api.telegram.org/bot$INPUT_BOT_TOKEN/getWebhookInfo"

# 2. 查看是否有错误
# 看 last_error_message 字段

# 3. 确认服务运行
ps aux | grep node
```

### Q: ChromaDB 连接失败

**解决**:
```bash
# 确认 Docker 运行
docker ps

# 重启 ChromaDB
docker restart chromadb

# 或重新启动
docker run -d --name chromadb -p 8000:8000 chromadb/chroma
```

### Q: OpenRouter API 报错

**检查**:
1. API Key 是否正确
2. 账户是否有余额
3. 模型名称是否正确（如 `anthropic/claude-3-haiku`）

## 📁 项目结构

```
meta-assistant/
├── bot/                    # Telegram Bot 代码
│   ├── index.js           # 主程序
│   └── package.json
├── admin/                  # Web 管理后台
│   ├── server.js          # 后端服务
│   ├── public/            # 前端文件
│   └── data/              # 配置数据
├── scripts/               # 脚本工具
│   ├── setup.sh          # 一键配置
│   ├── start.sh          # 启动脚本
│   ├── stop.sh           # 停止脚本
│   └── ecosystem.config.js # PM2 配置
├── docs/                  # 文档
│   └── TROUBLESHOOTING.md # 故障排除
├── .env.example           # 环境变量模板
└── README.md
```

## 🤝 贡献

欢迎提交 Issue 和 Pull Request！

## 📄 开源协议

MIT License

## 🙏 致谢

- [node-telegram-bot-api](https://github.com/yagop/node-telegram-bot-api)
- [ChromaDB](https://www.trychroma.com/)
- [OpenRouter](https://openrouter.ai/)
